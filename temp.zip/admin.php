<?php
session_start();
require 'session_check.php';
?>
<?php require 'admin_header.php'?>
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container">
				<div class="row">
                    <div class="col-lg-5 m-auto">
                        <div class="card">
                            <h1 class="text-bold m-auto">Hello buddy</h1>
                        </div>
                    </div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
		<?php require 'admin_footer.php'?>