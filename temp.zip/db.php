<?php
$hostname = 'localhost';
$hostuser = 'root';
$hostpassword = '';
$db_name = 'userinformaton';
$db_connect = mysqli_connect($hostname, $hostuser, $hostpassword, $db_name);
?>